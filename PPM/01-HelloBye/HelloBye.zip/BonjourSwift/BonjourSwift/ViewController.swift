//
//  ViewController.swift
//  BonjourSwift
//
//  Created by m2sar on 26/09/2017.
//  Copyright © 2017 UPMC. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var myLabel: UILabel!
    @IBOutlet weak var myButton: UIButton!
    var click = true
    
    
    override func viewDidLoad() {
        myButton.setTitle("Dis Bonjour",for: .normal)
        myLabel.text = "";
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    
    @IBAction func changeButton(_ sender: Any) {
        if(click == true) {
            myLabel.text = "Bonjour";
            click = false;
            myButton.setTitle("Dis Au revoir", for: .normal)
            print("normal");
        }
       
        else{
            myLabel.text = "Au revoir";
            click = true
            myButton.setTitle("Dis bonjour", for: .normal)
            print("click")
        }
         print(myButton.state)
    }
    
}

