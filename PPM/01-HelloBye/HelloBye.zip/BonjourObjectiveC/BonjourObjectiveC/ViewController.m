//
//  ViewController.m
//  BonjourObjectiveC
//
//  Created by m2sar on 25/09/2017.
//  Copyright © 2017 UPMC. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [_myLabel setText:@""];
    [_myButton setTitle:@"Dis Bonjour" forState:UIControlStateNormal];
    // Do any additional setup after loading the view, typically from a nib.
    NSLog(@"test");
}



- (IBAction)changeButton:(id)sender {
    NSString *temp = @"Dis Bonjour";
    if([[_myButton titleForState:UIControlStateNormal] isEqualToString:temp]){
        [_myLabel setText:@"Bonjour"];
        [_myButton setTitle:@"Dis Au Revoir" forState:UIControlStateNormal];
    }
    else{
        [_myLabel setText:@"Au revoir "];
        [_myButton setTitle:@"Dis Bonjour" forState:UIControlStateNormal];
    }

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
