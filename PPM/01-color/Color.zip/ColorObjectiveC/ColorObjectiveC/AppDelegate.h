//
//  AppDelegate.h
//  ColorObjectiveC
//
//  Created by m2sar on 25/09/2017.
//  Copyright © 2017 UPMC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

