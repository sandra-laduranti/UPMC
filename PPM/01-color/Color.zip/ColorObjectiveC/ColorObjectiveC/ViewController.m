//
//  ViewController.m
//  ColorObjectiveC
//
//  Created by m2sar on 25/09/2017.
//  Copyright © 2017 UPMC. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
 
    self.myStepper.wraps=YES;
    self.myStepper.autorepeat=YES;
    self.myStepper.maximumValue=3;
    self.myStepper.value = 0;
    self.myStepper.minimumValue= 0;
    
    [_myLabel setText:@"Change color"];    // Do any additional setup after loading the view, typically from a nib.
    [super viewDidLoad];
}


- (IBAction)valueChanged:(UIStepper *)sender {
    NSInteger value = [sender value];
    
    switch (value)
    {
        case 0:
            self.myView.backgroundColor = [UIColor redColor];
            break;
        case 1:
            self.myView.backgroundColor = [UIColor yellowColor];
            break;
        case 2:
            self.myView.backgroundColor = [UIColor blueColor];
            break;
        case 3:
            self.myView.backgroundColor = [UIColor greenColor];
            break;
        default:
            self.myView.backgroundColor = [UIColor clearColor];
            break;
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
