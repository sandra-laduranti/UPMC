//
//  ViewController.swift
//  colorSwift
//
//  Created by m2sar on 25/09/2017.
//  Copyright © 2017 UPMC. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var myView: UIView!
    
    @IBOutlet weak var myLabel: UILabel!
    
    @IBOutlet weak var myStepper: UIStepper!

    @IBAction func stepperValueChanged(_ sender: UIStepper) {
        self.myView.backgroundColor = UIColor.red
        
        switch sender.value {
        case 0:
            self.myView.backgroundColor = nil
        case 1:
            self.myView.backgroundColor = UIColor.red
        case 2:
            self.myView.backgroundColor = UIColor.blue
        case 3:
            self.myView.backgroundColor = UIColor.green
        case 4:
            self.myView.backgroundColor = UIColor.yellow
        default:
            self.myView.backgroundColor = nil
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        myStepper.wraps = true
        myStepper.autorepeat = true
        myStepper.maximumValue = 3
        myStepper.minimumValue = 0
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

   
}

