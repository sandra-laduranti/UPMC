//
//  ViewController.m
//  Dizainier
//
//  Created by m2sar on 29/09/2017.
//  Copyright © 2017 UPMC. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

//utiliser compteur ui stepper

@implementation ViewController




- (void)viewDidLoad {
    //init stepper
    _stepperDizainier.wraps = YES;
    _stepperDizainier.continuous = YES;
    _stepperDizainier.maximumValue = 99;
    _stepperDizainier.minimumValue = 0;
    _stepperDizainier.autorepeat = YES;
    //init slider
    _sliderDizainier.value = 0;
    _sliderDizainier.maximumValue = 99;
    _sliderDizainier.minimumValue = 0;
    //init switch
    _switchGeek.on = false;
    
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)dealloc {
    [_stepperDizainier release];
    [_labelValue release];
    [_segmentDizaine release];
    [_segmentUnite release];
    [_sliderDizainier release];
    [_switchGeek release];
    [super dealloc];
}

- (void)changeViewValues:(int)val{
    int diz = val/10;
    int uni = floor(val%10);
    
    //set des segments
    if (_segmentDizaine.selectedSegmentIndex != diz)
        _segmentDizaine.selectedSegmentIndex = diz;
    if (_segmentUnite.selectedSegmentIndex != uni)
        _segmentUnite.selectedSegmentIndex = uni;
    //set stepper
    if (_stepperDizainier.value != (double)val)
        _stepperDizainier.value = (double)val;
    //set slider
    if (_sliderDizainier.value != (float)val)
        _sliderDizainier.value = (float)val;
    //set du Label
    _labelValue.textColor = (val == 42) ? [UIColor redColor] : [UIColor blackColor];
    if(!_switchGeek.isOn)
        [_labelValue setText:[NSString stringWithFormat:@"%d", val]];
    else
        [_labelValue setText:[NSString stringWithFormat:@"%x", val]];
}

- (IBAction)changeStepperVal:(UIStepper *)sender {
    double value = [sender value];
    [self changeViewValues:(int)value];
}

- (IBAction)changeSegment:(id)sender {
    int newVal = (int)_segmentDizaine.selectedSegmentIndex*10 + (int)_segmentUnite.selectedSegmentIndex;
    [self changeViewValues:(int)newVal];
}

- (IBAction)changeSlider:(UISlider *)sender {
    [self changeViewValues:(int)sender.value];
}

- (IBAction)changeSwitch:(UISwitch *)sender {
    _labelValue.textColor = ((int)_stepperDizainier.value == 42) ? [UIColor redColor] : [UIColor blackColor];
    if(!_switchGeek.isOn)
        [_labelValue setText:[NSString stringWithFormat:@"%d", (int)_stepperDizainier.value]];
    else
        [_labelValue setText:[NSString stringWithFormat:@"%x", (int)_stepperDizainier.value]];
}

- (IBAction)remiseAzero:(id)sender {
    [self changeViewValues:0];}






@end
