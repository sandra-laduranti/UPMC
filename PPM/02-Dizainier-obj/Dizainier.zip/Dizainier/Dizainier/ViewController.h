//
//  ViewController.h
//  Dizainier
//
//  Created by m2sar on 29/09/2017.
//  Copyright © 2017 UPMC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (retain, nonatomic) IBOutlet UIStepper *stepperDizainier;
@property (retain, nonatomic) IBOutlet UILabel *labelValue;
@property (retain, nonatomic) IBOutlet UISegmentedControl *segmentDizaine;
@property (retain, nonatomic) IBOutlet UISegmentedControl *segmentUnite;
@property (retain, nonatomic) IBOutlet UISlider *sliderDizainier;
@property (retain, nonatomic) IBOutlet UISwitch *switchGeek;

- (void)changeViewValues:(int)val;
- (IBAction)changeStepperVal:(UIStepper *)sender;
- (IBAction)changeSegment:(id)sender;
- (IBAction)changeSlider:(UISlider *)sender;
- (IBAction)changeSwitch:(UISwitch *)sender;
- (IBAction)remiseAzero:(id)sender;


@end

