//
//  ViewController.swift
//  Quizz
//
//  Created by m2sar on 02/10/2017.
//  Copyright © 2017 UPMC. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var question: UITextView!
    @IBOutlet weak var reponse: UITextView!
    @IBOutlet weak var buttonReponse: UIButton!
    @IBOutlet weak var buttonNext: UIButton!
    @IBOutlet weak var buttonPrev: UIButton!
    @IBOutlet weak var buttonDifficult: UISwitch!
    @IBOutlet weak var reponsesVues: UILabel!
    
    var currentQuestion = 0
    
    var questionList = Quizz(q:"Quelle est la couleur du cheval blanc d'henri IV?",r:"Blanc",d:false)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //set questions
        questionList.addQuestion(q:"La réponse à la grande question sur la vie, l'univers et le reste?",r:"42",d:false)
        questionList.addQuestion(q:"Sur quoi est posé le disque du monde ?",r:"Sur quatre éléphants eux-même posés sur une tortue",d:true)
        questionList.addQuestion(q:"1 + 1 ?",r:"2",d:false)
        questionList.addQuestion(q:"La boule de cristal léguée à Goku par son grand-père a combien d'étoiles?",r:"4",d:true)
        questionList.addQuestion(q:"Qui est l'auteur du Seigneur des anneaux?",r:"J.R.R. Tolkien",d:false)
        //set text
        reponse.textColor = UIColor.green
        question.isEditable = false
        question.text = questionList.getCurrentQuestion()
        reponse.isEditable = false
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func handleAff(affQuestion: String, affReponse: String){
        question.textColor = questionList.currentDifficulty() ? UIColor.red : UIColor.blue
        question.text = affQuestion
        if (affReponse == "" && questionList.reponseIsOn()){
            reponse.text = questionList.getCurrentResponse()
        }
        else{
            reponse.text = affReponse
        }
        reponsesVues.text = "Réponses vues: \(questionList.nbRep)"
    }

    @IBAction func askReponse(_ sender: UIButton) {
        handleAff(affQuestion: questionList.getCurrentQuestion(), affReponse: questionList.getCurrentResponse())
    }
    
    @IBAction func changeQuestion(_ sender: UIButton) {
        if (sender.tag == 1){
            //next
            handleAff(affQuestion: questionList.nextQuestion(), affReponse: "")
        }
        if (sender.tag == 2){
            //prev
            handleAff(affQuestion: questionList.prevQuestion(), affReponse: "")
        }
    }
    
    @IBAction func changeDifficulty(_ sender: UISwitch) {
        questionList.difficulty = sender.isOn ? true : false ;
        
        if(!sender.isOn && questionList.currentDifficulty()){
            questionList.nextQuestion();
            handleAff(affQuestion: questionList.nextQuestion(), affReponse: "")
        }
    }

}
