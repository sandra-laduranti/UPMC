//
//  Quizz.swift
//  Quizz
//
//  Created by m2sar on 04/10/2017.
//  Copyright © 2017 UPMC. All rights reserved.
//

import Foundation


class Quizz{

    var questions = [(question:String, reponse:String, difficulty:Bool, reponseOn:Bool)]()
    var nbRep = 0
    var currentQuestion: Int = 0
    var difficulty = false;
    
    init(q: String, r: String, d: Bool) {
        self.questions.append((q, r, d, false))
    }
    
    func addQuestion(q: String, r: String, d: Bool){
        questions.append((q, r, d, false))
    }
    
    func currentDifficulty()->Bool{
        return questions[currentQuestion].difficulty;
    }
    
    func getCurrentQuestion()->String{
        return questions[currentQuestion].question
    }
    
    
    func getCurrentResponse()->String{
        if (!questions[currentQuestion].reponseOn){
            nbRep = nbRep + 1
        }
        questions[currentQuestion].reponseOn = true
        return questions[currentQuestion].reponse
    }
    
    func reponseIsOn()->Bool{
        return questions[currentQuestion].reponseOn
    }
    
    func nextQuestion()->String{
        let questionsSize = questions.count
        
        currentQuestion = (currentQuestion+1)%questionsSize;
        
        if (difficulty == true){
            return questions[currentQuestion].question
        }
        
        while(questions[currentQuestion].difficulty == true){
            currentQuestion = (currentQuestion+1)%questionsSize;
        }
        
        return questions[currentQuestion].question
    }
    
    func prevQuestion()->String{
        let questionsSize = questions.count
        
        currentQuestion = currentQuestion == 0 ? questionsSize-1 : (currentQuestion-1)

        if (difficulty == true){
            return questions[currentQuestion].question
        }
        
        while (questions[currentQuestion].difficulty == true){
            currentQuestion = currentQuestion == 0 ? questionsSize-1 : (currentQuestion-1)
        }
        
        return questions[currentQuestion].question
    }
 
    
}
