//
//  ViewController.m
//  Nuancier RVB
//
//  Created by m2sar on 29/09/2017.
//  Copyright © 2017 UPMC. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //set color button
    _buttonActuel.backgroundColor = [UIColor grayColor];
    _buttonPrecedent.backgroundColor = [UIColor grayColor];
    _buttonPenultieme.backgroundColor = [UIColor grayColor];
    //set sliders Values
    _sliderRouge.value = 0.5;
    _sliderVert.value = 0.5;
    _sliderBleu.value = 0.5;
    _sliderBleu.minimumValue = 0;
    _sliderBleu.maximumValue = 1;
    _sliderVert.minimumValue = 0;
    _sliderVert.maximumValue = 1;
    _sliderRouge.minimumValue = 0;
    _sliderRouge.maximumValue = 1;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)dealloc {
    [_buttonActuel release];
    [_buttonPrecedent release];
    [_buttonPenultieme release];
    [_labelRouge release];
    [_labelVert release];
    [_labelBleu release];
    [_sliderRouge release];
    [_sliderVert release];
    [_sliderBleu release];
    [_switchWeb release];
    [super dealloc];
}

//gère tout l'affichage
- (void)handleAff{
    _labelRouge.text = [NSString stringWithFormat: @"R: %d %%", (int)(_sliderRouge.value * 100)];
    _labelBleu.text = [NSString stringWithFormat: @"B: %d %%", (int)(_sliderBleu.value * 100)];
    _labelVert.text = [NSString stringWithFormat: @"V: %d %%", (int)(_sliderVert.value * 100)];
    _buttonActuel.backgroundColor = [UIColor colorWithRed:_sliderRouge.value green:_sliderVert.value blue:_sliderBleu.value alpha:1.1];
}



- (void)webMode{
    _sliderBleu.value = (round((_sliderBleu.value*100)/10)*10)/100;
    _sliderVert.value = (round((_sliderVert.value*100)/10)*10)/100;
    _sliderRouge.value = (round((_sliderRouge.value*100)/10)*10)/100;
    [self handleAff];
}


//update la valeur des sliders
- (IBAction)changeSliderValue:(UISlider *)sender {
    if(_switchWeb.isOn)
        [self webMode];
    [self handleAff];
}

//Enregistre la couleur
- (IBAction)memorise:(id)sender {
    _buttonPenultieme.backgroundColor = _buttonPrecedent.backgroundColor;
    _buttonPrecedent.backgroundColor = _buttonActuel.backgroundColor;
}

//remet à zero actuel
- (IBAction)raz:(id)sender {
    _sliderRouge.value = 0.5;
    _sliderVert.value = 0.5;
    _sliderBleu.value = 0.5;
    [self handleAff];
}

//reset Actuel à la valeur de penul ou précédent
- (IBAction)recupOld:(UIButton *)sender {
    const CGFloat* components = CGColorGetComponents(sender.backgroundColor.CGColor);
    _sliderRouge.value = components[0];
    _sliderVert.value = components[1];
    _sliderBleu.value = components[2];
    if(_switchWeb.isOn)
        [self webMode];
    [self handleAff];
}



- (IBAction)setWeb:(id)sender {
      if(_switchWeb.isOn)
          [self webMode];
     [self handleAff];
}




@end
