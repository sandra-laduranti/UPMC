//
//  ViewController.h
//  Nuancier RVB
//
//  Created by m2sar on 29/09/2017.
//  Copyright © 2017 UPMC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (retain, nonatomic) IBOutlet UIButton *buttonActuel;
@property (retain, nonatomic) IBOutlet UIButton *buttonPrecedent;
@property (retain, nonatomic) IBOutlet UIButton *buttonPenultieme;

@property (retain, nonatomic) IBOutlet UILabel *labelRouge;
@property (retain, nonatomic) IBOutlet UILabel *labelVert;
@property (retain, nonatomic) IBOutlet UILabel *labelBleu;

@property (retain, nonatomic) IBOutlet UISlider *sliderRouge;
@property (retain, nonatomic) IBOutlet UISlider *sliderVert;
@property (retain, nonatomic) IBOutlet UISlider *sliderBleu;

@property (retain, nonatomic) IBOutlet UISwitch *switchWeb;

- (IBAction)changeSliderValue:(UISlider *)sender;

- (IBAction)memorise:(id)sender;
- (IBAction)raz:(id)sender;
- (IBAction)recupOld:(UIButton *)sender;

- (IBAction)setWeb:(id)sender;

- (void)webMode;
- (void)handleAff;

@end

