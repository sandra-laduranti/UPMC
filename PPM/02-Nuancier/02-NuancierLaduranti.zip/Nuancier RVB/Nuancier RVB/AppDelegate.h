//
//  AppDelegate.h
//  Nuancier RVB
//
//  Created by m2sar on 29/09/2017.
//  Copyright © 2017 UPMC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

