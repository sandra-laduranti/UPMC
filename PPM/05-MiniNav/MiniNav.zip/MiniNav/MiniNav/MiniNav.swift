//
//  MiniNav.swift
//  MiniNav
//
//  Created by m2sar on 22/10/2018.
//  Copyright © 2018 UPMC. All rights reserved.
//

import Foundation
/*
class MiniNav {
    private var historique = [String]()
    private var cur = 0
    private var home = String("https://www.google.com")
    
    init(){
        print("init")
        print("avant init", historique.debugDescription)
        historique.append(home)
        print("apres init", historique.debugDescription)
    }
    
    func getHistorique()->[String]{
        return historique
    }
    
    func cleanFuturHistorique(num: Int){
        print("clean hist", num)
        let histSize = historique.count
        for index in num..<histSize {
            historique.remove(at: index)
        }
    }
    
    //si on est retourné  en arrière et qu'on change de page, l'historique est reset
    //on suppr tout ce qui suivait et on devient la nouvelle fin
    func addToHistorique(url: String){
        print("hist:", historique.count , url, cur)
        historique.count-1 > cur ? cleanFuturHistorique(num: cur+1) : nil
        historique.append(url)
        cur = historique.count-1
        print("addToHist: ", cur )
    }
   
    func next(){
        cur = (cur+1<historique.count) ? cur+1 : cur
        print("next: ", cur)
    }
    
    func prev(){
        cur = (cur-1<0) ? 0 : cur - 1
    }
    
    func goHome(){
        addToHistorique(url: home)
    }
    
    func getCur()->Int{
        return cur
    }
    
    func getHome()->String{
        return home
    }
    
    func setHome(url: String){
        home = url
    }
    
    func getUrl()->String{
        print("cur: %f",cur)
        print("dans geturl " + historique[cur])
        print(historique.debugDescription)
        return historique[cur]
    }
    
    func togglePrev()->Bool{
        return ((cur != 0) ? true : false)
     }
    
    func toggleNext()->Bool{
         return ((cur != historique.count-1) ? true : false)
    }
}
*/
