//
//  MiniNavView.swift
//  MiniNav
//
//  Created by m2sar on 22/10/2018.
//  Copyright © 2018 UPMC. All rights reserved.
//

import UIKit
import WebKit

class MiniNavView: UIView, WKNavigationDelegate {
    
    private var viewController: ViewController!
    
    private let toolBar = UIToolbar()
    public var webView: WKWebView!
    
    private let smallAct = UIActivityIndicatorView()

    
    enum TagB: Int {case GETHOMEB, PREVB, NEXTB, ADDRESSB, SETHOMEB}
    
    //private let busyB = UIBarButtonItem(customView: UIActivityIndicatorView())
    //spaceB to handle aff, automatic space between buttons in the UIToolBar
    private var getHomeB, prevB, nextB, addressB, setHomeB, spaceB: UIBarButtonItem!
   
  required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override init (frame: CGRect){
        super.init(frame: frame)
    }
    
    convenience init (frame: CGRect, controller: ViewController){
        self.init(frame: frame)
        
        self.viewController = controller
        
        getHomeB = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.refresh, target: viewController, action:  #selector(viewController.loadPage(sender:)))
        prevB = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.rewind, target: viewController, action:  #selector(viewController.loadPage(sender:)))
        nextB = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.fastForward, target: viewController, action:  #selector(viewController.loadPage(sender:)))
        addressB = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.action, target: viewController, action:  #selector(viewController.handleAlert))
        setHomeB = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.compose, target: viewController, action:  #selector(viewController.handleAlert))
        spaceB = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: self, action: nil)
        
        /*init de tous les éléments*/
        toolBar.isTranslucent = true
        toolBar.tintColor = UIColor.red
        toolBar.backgroundColor = UIColor.gray
        
        // make toolBar buttons
        getHomeB.tag = TagB.GETHOMEB.rawValue
        prevB.tag = TagB.PREVB.rawValue
        nextB.tag = TagB.NEXTB.rawValue
        addressB.tag = TagB.ADDRESSB.rawValue
        setHomeB.tag = TagB.SETHOMEB.rawValue
        
        prevB.tintColor = UIColor.white
        nextB.tintColor = UIColor.white
       
        prevB.isEnabled = false
        nextB.isEnabled = false
        
        
        smallAct.color = UIColor.white
        smallAct.hidesWhenStopped = true
        
        let busyB = UIBarButtonItem(customView: smallAct)
        toolBar.items = [getHomeB,busyB,spaceB, prevB,spaceB, addressB,spaceB, nextB,spaceB, setHomeB]
        
        
        
        let webConfiguration = WKWebViewConfiguration()
        webView = WKWebView(frame: .zero, configuration: webConfiguration)
        webView.navigationDelegate = self
        //webView.uiDelegate = self
        self.addSubview(toolBar)
        self.addSubview(webView)
        
    }
    
    override func draw(_ rect: CGRect) {
        toolBar.frame = CGRect(x: CGFloat(0), y: CGFloat(20), width: CGFloat(rect.size.width), height: 20)
        webView.frame = CGRect(x: 0, y: CGFloat(40), width: CGFloat(rect.size.width), height: CGFloat(rect.size.height)-40)
    }
    
    func changePage(myUrl: URL){
        let myRequest = URLRequest(url: myUrl)
        webView.load(myRequest)
        smallAct.startAnimating()

    }
    
    /*func webView(_: WKWebView, didStartProvisionalNavigation: WKNavigation!) {
        print("web view begins to receive web content.")
    }*/
    
    /*func webView(_: WKWebView, didCommit: WKNavigation!) {
        print("web content begins to load in a web view")
    }*/
    
    
    func webView(_: WKWebView, didFinish: WKNavigation!) {
        print("navigation is complete")
        smallAct.stopAnimating();
        prevB.isEnabled = (webView.canGoBack ? true : false)
        nextB.isEnabled = (webView.canGoForward ? true : false)
    }
 
   func webView(_ webView: WKWebView,
                 didFailProvisionalNavigation navigation: WKNavigation!,
                 withError error: Error) {
        print("in webview error")
        if error._code != 200 && error._code != -999 {
            viewController.errorHandler(num: error._code, message: error.localizedDescription)
        }
        if error._code == -1001 { // TIMED OUT:
            viewController.errorHandler(num: error._code, message: error.localizedDescription)
            print("timeout")
        } else if error._code == -1003 { // SERVER CANNOT BE FOUND
            print("server not found")
             viewController.errorHandler(num: error._code, message: error.localizedDescription)
        } else if error._code == -1100 { // URL NOT FOUND ON SERVER
            print("url not found")
             viewController.errorHandler(num: error._code, message: error.localizedDescription)
        }
    }
    
    func webView(_ webView: WKWebView, decidePolicyFor: WKNavigationResponse, decisionHandler: (WKNavigationResponsePolicy) -> Void) {
        print("decision handler")
        if(decidePolicyFor.response .isKind(of: HTTPURLResponse.self)){
            let response = decidePolicyFor.response as! HTTPURLResponse
            
          /*  if(response.statusCode == 401){
                print("error")
            }*/
            if(response.statusCode >= 404){
                viewController.errorHandler(num: response.statusCode, message: response.description)
            }
        }
        decisionHandler(WKNavigationResponsePolicy.allow)
    }
    
    func webView(_ webView: WKWebView, didReceiveServerRedirectForProvisionalNavigation navigation: WKNavigation!) {
        let url = URL(string: webView.url!.absoluteString)
        if (url != nil){
            let request = URLRequest(url: url!)
            webView.load(request)
        } else {
            print("Bad redirection")
        }
    }
    
    func forwardInWebView(){
        webView.goForward()
    }
    
    func backwardInWebView(){
        webView.goBack()
    }
    
    func togglePrev(state: Bool){
        prevB.isEnabled = state
    }
    
    func toggleNext(state: Bool){
        nextB.isEnabled = state
    }
    
}



