//
//  ViewController.swift
//  MiniNav
//
//  Created by m2sar on 22/10/2018.
//  Copyright © 2018 UPMC. All rights reserved.
//

import UIKit
import WebKit

class ViewController: UIViewController, WKNavigationDelegate {
    
    /*override func loadView() {
     let webConfiguration = WKWebViewConfiguration()
     webView = WKWebView(frame: .zero, configuration: webConfiguration)
     webView.uiDelegate = self
     view = webView
     }
     override func viewDidLoad() {
     super.viewDidLoad()
     
     let myURL = URL(string:"https://www.apple.com")
     let myRequest = URLRequest(url: myURL!)
     webView.load(myRequest)
     }}*/
    
    private var home = String("https://www.google.com")
    
    private let errorA = UIAlertController(title: "Error", message: "Unknown error" , preferredStyle: .alert)
    
    private let changeHomeA = UIAlertController(title: "Change Home", message: "Enter URL Home", preferredStyle: .alert)
    private let changeUrlA = UIAlertController(title: "Change Page", message: "Enter URL", preferredStyle: .alert)
    
    private var urlRep : UITextField?
    
    override func loadView(){
        view = MiniNavView(frame: UIScreen.main.bounds, controller: self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
       if let v = self.view as? MiniNavView {
            let myURL = URL(string:home)
            let myRequest = URLRequest(url: myURL!)
            v.webView.load(myRequest)
            //miniNav.addToHistorique(url: miniNav.getHome())
        }
        
        errorA.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        
        changeUrlA.addAction(UIAlertAction(title: "OK", style:.default, handler: changeURL))
        changeUrlA.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        changeUrlA.addTextField(configurationHandler: {textField -> Void in
            textField.text = self.home
            self.urlRep = textField
        })
        
        changeHomeA.addAction(UIAlertAction(title: "OK", style:.default, handler: changeHome))
        changeHomeA.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        changeHomeA.addTextField(configurationHandler: {textField -> Void in
            textField.text = self.home
            self.urlRep = textField
        })
        
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        if let v = self.view as? MiniNavView {
            v.draw(CGRect(x: 0, y: 0, width: size.width, height: size.height))
        }
    }
    
    @IBAction func loadPage(sender: UIBarButtonItem){
        if let mavue = self.view as? MiniNavView {
            switch(sender.tag){
            case MiniNavView.TagB.NEXTB.rawValue: mavue.forwardInWebView()
            break;
            case MiniNavView.TagB.PREVB.rawValue: mavue.backwardInWebView()
            break;
            case MiniNavView.TagB.GETHOMEB.rawValue: mavue.changePage(myUrl: URL(string: self.home)!)
            break;
            default: print("error")
            return;
            }
            
        }
    }
    
     @IBAction func handleAlert(sender: UIBarButtonItem){
        var aler:UIAlertController = changeHomeA
        switch sender.tag {
        case MiniNavView.TagB.ADDRESSB.rawValue:
            aler = changeUrlA
            break;
        case MiniNavView.TagB.SETHOMEB.rawValue:
            aler = changeHomeA
            break;
        default:
            print("ERROR!!")
            return;
        }
        
        if ((self.view as? MiniNavView) != nil) {
            self.present(aler, animated: true, completion: nil)
        }
    }
    
    @IBAction func changeURL(alert: UIAlertAction!){
        //miniNav.addToHistorique(url: (urlRep?.text)!)
        print("test", changeUrlA.textFields ?? 42)
        print("change url", (changeUrlA.textFields?.first?.text)!)
        if let mavue = self.view as? MiniNavView {
            mavue.changePage(myUrl: URL(string: (changeUrlA.textFields?.first?.text)!)!)
        }
    }
    
    @IBAction func changeHome(alert: UIAlertAction!){
        print("change home", (changeHomeA.textFields?.first?.text)!)
        if let mavue = self.view as? MiniNavView {
            mavue.changePage(myUrl: URL(string: (changeHomeA.textFields?.first?.text)!)!)
        }
    }
    
   
    func errorHandler(num: Int, message: String){
        errorA.title = (num == 200) ? "error" : "error \(num)"
        errorA.message = message
        
        if ((self.view as? MiniNavView) != nil) {
            self.present(errorA, animated: true, completion: nil)
        }
    }
    
}

