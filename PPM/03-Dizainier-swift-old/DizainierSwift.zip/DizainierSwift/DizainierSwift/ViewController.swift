//
//  ViewController.swift
//  DizainierSwift
//
//  Created by m2sar on 02/10/2017.
//  Copyright © 2017 UPMC. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var stepperDizainier: UIStepper!
    @IBOutlet weak var switchGeek: UISwitch!
    @IBOutlet weak var dizainesSeg: UISegmentedControl!
    @IBOutlet weak var unitesSeg: UISegmentedControl!
    @IBOutlet weak var sliderDizainier: UISlider!
    @IBOutlet var labelValue: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        stepperDizainier.maximumValue = 99
        stepperDizainier.minimumValue = 0
        sliderDizainier.minimumValue = 0
        sliderDizainier.maximumValue = 99
        sliderDizainier.value = 0
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func handleView(val: Int) {
        let diz = val/10;
        let uni = Int(floor(Double(val%10)));
        
        print("val \(val) diz \(diz) uni \(uni) total \(diz*10 + uni) ")
        
        dizainesSeg.selectedSegmentIndex = diz
        unitesSeg.selectedSegmentIndex = uni
        stepperDizainier.value = (Double(val))
        sliderDizainier.value = Float(val)
        labelValue.textColor = (val == 42) ? UIColor.red : UIColor.black
        if (!switchGeek.isOn){
            labelValue.text = String(val)
        }
        else{
            labelValue.text = String(format:"%2X",val)
        }
    
    }

    @IBAction func changeStepper(_ sender: UIStepper) {
         handleView(val: Int(sender.value))
    }

    @IBAction func changeSegment(_ sender: UISegmentedControl) {
        let newVal = dizainesSeg.selectedSegmentIndex*10 + unitesSeg.selectedSegmentIndex;
        
        handleView(val: Int(newVal))
    }

    @IBAction func geekMode(_ sender: UISwitch) {
        handleView(val: Int(stepperDizainier.value))
    }
    
    @IBAction func changeSlider(_ sender: UISlider) {
        handleView(val: Int(sender.value))
    }
    
    @IBAction func raz(_ sender: UIButton) {
        handleView(val: 0)
    }
}

