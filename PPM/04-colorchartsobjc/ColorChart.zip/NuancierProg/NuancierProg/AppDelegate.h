//
//  AppDelegate.h
//  NuancierProg
//
//  Created by m2sar on 18/10/2018.
//  Copyright © 2018 UPMC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

