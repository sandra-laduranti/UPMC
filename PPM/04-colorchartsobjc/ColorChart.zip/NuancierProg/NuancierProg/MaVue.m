//
//  MaVue.m
//  NuancierProg
//
//  Created by m2sar on 18/10/2018.
//  Copyright © 2018 UPMC. All rights reserved.
//

#import "MaVue.h"

@implementation MaVue

UIButton *buttonActuel;
UIButton *buttonPrecedent;
UIButton *buttonPenultieme;
UIButton *buttonRaz;
UIButton *buttonMemoriser;


UILabel *labelPenultieme;
UILabel *labelPrecedent;
UILabel *labelActuel;
UILabel *labelRouge;
UILabel *labelVert;
UILabel *labelBleu;
UILabel *labelWeb;

UISlider *sliderRouge;
UISlider *sliderVert;
UISlider *sliderBleu;

UISwitch *switchWeb;


- (id) initWithFrame:(CGRect)frame{
    /*init labels*/
    [super initWithFrame:frame];
    [self setBackgroundColor:[UIColor whiteColor]];
    labelRouge = [[UILabel alloc]init];
    [labelRouge setText:@"r: 50%"];
    [labelRouge setTextAlignment:NSTextAlignmentCenter];
    labelVert = [[UILabel alloc]init];
    [labelVert setText:@"v: 50%"];
    [labelVert setTextAlignment:NSTextAlignmentCenter];
    labelBleu = [[UILabel alloc]init];
    [labelBleu setText:@"b: 50%"];
    [labelBleu setTextAlignment:NSTextAlignmentCenter];
    labelWeb = [[UILabel alloc]init];
    [labelWeb setText:@"web"];
    [labelWeb setTextAlignment:NSTextAlignmentCenter];
    labelPenultieme = [[UILabel alloc]init];
    [labelPenultieme setText:@"Penultième"];
    [labelPenultieme setTextAlignment:NSTextAlignmentCenter];
    labelPrecedent = [[UILabel alloc]init];
    [labelPrecedent setText:@"Precedent"];
    [labelPrecedent setTextAlignment:NSTextAlignmentCenter];
    labelActuel = [[UILabel alloc]init];
    [labelActuel setText:@"Actuel"];
    [labelActuel setTextAlignment:NSTextAlignmentCenter];
    
    /* slider */
    sliderRouge = [[UISlider alloc]init];
    sliderRouge.minimumValue = 0;
    sliderRouge.maximumValue = 1;
    sliderRouge.continuous = NO;
    sliderRouge.value = 0.5;
    [sliderRouge addTarget:self
                     action:@selector(changeSliderValue:)
           forControlEvents:UIControlEventTouchUpInside];
    sliderVert = [[UISlider alloc]init];
    sliderVert.minimumValue = 0;
    sliderVert.maximumValue = 1;
    sliderVert.continuous = NO;
    sliderVert.value = 0.5;
    [sliderVert addTarget:self
                    action:@selector(changeSliderValue:)
          forControlEvents:UIControlEventTouchUpInside];
    sliderBleu = [[UISlider alloc]init];
    sliderBleu.minimumValue = 0;
    sliderBleu.maximumValue = 1;
    sliderBleu.continuous = NO;
    sliderBleu.value = 0.5;
    [sliderBleu addTarget:self
                    action:@selector(changeSliderValue:)
          forControlEvents:UIControlEventTouchUpInside];
    
    /* init buttons */
    buttonActuel = [UIButton buttonWithType:UIButtonTypeCustom];
    buttonActuel.frame = CGRectMake(0,0,100,15);
    buttonActuel.backgroundColor = [UIColor grayColor];
    buttonPrecedent = [UIButton buttonWithType:UIButtonTypeCustom];
    buttonPrecedent.frame = CGRectMake(0,0,100,15);
    buttonPrecedent.backgroundColor = [UIColor grayColor];
    [buttonPrecedent addTarget:self
                   action:@selector(recupOld:)
         forControlEvents:UIControlEventTouchUpInside];
    buttonPenultieme = [UIButton buttonWithType:UIButtonTypeCustom];
    buttonPenultieme.frame = CGRectMake(0,0,100,15);
    buttonPenultieme.backgroundColor = [UIColor grayColor];
    [buttonPenultieme addTarget:self
                   action:@selector(recupOld:)
         forControlEvents:UIControlEventTouchUpInside];
    buttonMemoriser = [UIButton buttonWithType:UIButtonTypeSystem];
    [buttonMemoriser setTitle:@"Memoriser" forState:UIControlStateNormal];
    [buttonMemoriser addTarget:self
                   action:@selector(memorise:)
         forControlEvents:UIControlEventTouchUpInside];
    buttonRaz = [UIButton buttonWithType:UIButtonTypeSystem];
    [buttonRaz setTitle:@"raz" forState:UIControlStateNormal];
    [buttonRaz addTarget:self
                   action:@selector(raz:)
         forControlEvents:UIControlEventTouchUpInside];
    switchWeb =[[UISwitch alloc] initWithFrame: CGRectZero];
    [switchWeb setOn:NO];
    [switchWeb addTarget:self
                   action:@selector(webMode)
         forControlEvents:UIControlEventTouchUpInside];
    
    
    labelPenultieme.translatesAutoresizingMaskIntoConstraints = NO;
    labelPrecedent.translatesAutoresizingMaskIntoConstraints = NO;
    labelActuel.translatesAutoresizingMaskIntoConstraints = NO;
    labelRouge.translatesAutoresizingMaskIntoConstraints = NO;
    labelVert.translatesAutoresizingMaskIntoConstraints = NO;
    labelBleu.translatesAutoresizingMaskIntoConstraints = NO;
    labelWeb.translatesAutoresizingMaskIntoConstraints = NO;
    buttonPenultieme.translatesAutoresizingMaskIntoConstraints = NO;
    buttonPrecedent.translatesAutoresizingMaskIntoConstraints = NO;
    buttonActuel.translatesAutoresizingMaskIntoConstraints = NO;
    buttonMemoriser.translatesAutoresizingMaskIntoConstraints = NO;
    buttonRaz.translatesAutoresizingMaskIntoConstraints = NO;
    switchWeb.translatesAutoresizingMaskIntoConstraints = NO;
    sliderRouge.translatesAutoresizingMaskIntoConstraints = NO;
    sliderVert.translatesAutoresizingMaskIntoConstraints = NO;
    sliderBleu.translatesAutoresizingMaskIntoConstraints = NO;
    
    
    [self addSubview:labelPenultieme];
    [labelPenultieme release];
    [self addSubview:labelPrecedent];
    [labelPrecedent release];
    [self addSubview:labelActuel];
    [labelActuel release];
    [self addSubview:labelRouge];
    [labelRouge release];
    [self addSubview:labelVert];
    [labelVert release];
    [self addSubview:labelBleu];
    [labelBleu release];
    [self addSubview:labelWeb];
    [labelWeb release];
    [self addSubview:buttonActuel];
    [buttonActuel release];
    [self addSubview:buttonPrecedent];
    [buttonPrecedent release];
    [self addSubview:buttonPenultieme];
    [buttonPenultieme release];
    [self addSubview:buttonMemoriser];
    [buttonMemoriser release];
    [self addSubview:buttonRaz];
    [buttonRaz release];
    [self addSubview:sliderRouge];
    [sliderRouge release];
    [self addSubview:sliderVert];
    [sliderVert release];
    [self addSubview:sliderBleu];
    [sliderBleu release];
    [self addSubview:switchWeb];
    [switchWeb release];

    [self initConstraints];
    return self;
}


- (void) initConstraints {
    
    NSLayoutConstraint *labelPenultiemeHaut = [NSLayoutConstraint constraintWithItem:labelPenultieme attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeTop multiplier:1.0 constant:20];
    [self addConstraint:labelPenultiemeHaut];
    NSLayoutConstraint *labelPenultiemeCenter = [NSLayoutConstraint constraintWithItem:labelPenultieme attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeCenterX multiplier:1.0 constant:0];
    [self addConstraint:labelPenultiemeCenter];
    NSLayoutConstraint *buttonPenultiemeHaut = [NSLayoutConstraint constraintWithItem:buttonPenultieme attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:labelPenultieme attribute:NSLayoutAttributeBottom multiplier:1.0 constant:5];
    [self addConstraint:buttonPenultiemeHaut];
   NSLayoutConstraint *buttonPenultiemeCenter = [NSLayoutConstraint constraintWithItem:buttonPenultieme attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeCenterX multiplier:1.0 constant:0];
    [self addConstraint:buttonPenultiemeCenter];
    NSLayoutConstraint *buttonPenultiemeGauche = [NSLayoutConstraint constraintWithItem:buttonPenultieme attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeLeft multiplier:1.0 constant:15];
    [self addConstraint:buttonPenultiemeGauche];
    NSLayoutConstraint *buttonPenultiemeDroite = [NSLayoutConstraint constraintWithItem:buttonPenultieme attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeRight multiplier:1.0 constant:-15];
   [self addConstraint:buttonPenultiemeDroite];
    NSLayoutConstraint *labelPrecedentHaut = [NSLayoutConstraint constraintWithItem:labelPrecedent attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:buttonPenultieme attribute:NSLayoutAttributeBottom multiplier:1.0 constant:5];
    [self addConstraint:labelPrecedentHaut];
    NSLayoutConstraint *labelPrecedentCenter = [NSLayoutConstraint constraintWithItem:labelPrecedent attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeCenterX multiplier:1.0 constant:0];
    [self addConstraint:labelPrecedentCenter];
    NSLayoutConstraint *buttonPrecedentHaut = [NSLayoutConstraint constraintWithItem:buttonPrecedent attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:labelPrecedent attribute:NSLayoutAttributeBottom multiplier:1.0 constant:5];
    [self addConstraint:buttonPrecedentHaut];
    NSLayoutConstraint *buttonPrecedentCenter = [NSLayoutConstraint constraintWithItem:buttonPrecedent attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeCenterX multiplier:1.0 constant:0];
    [self addConstraint:buttonPrecedentCenter];
    NSLayoutConstraint *buttonPrecedentGauche = [NSLayoutConstraint constraintWithItem:buttonPrecedent attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeLeft multiplier:1.0 constant:15];
    [self addConstraint:buttonPrecedentGauche];
    NSLayoutConstraint *buttonPrecedentDroite = [NSLayoutConstraint constraintWithItem:buttonPrecedent attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeRight multiplier:1.0 constant:-15];
    [self addConstraint:buttonPrecedentDroite];
    NSLayoutConstraint *labelActuelHaut = [NSLayoutConstraint constraintWithItem:labelActuel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:buttonPrecedent attribute:NSLayoutAttributeBottom multiplier:1.0 constant:5];
    [self addConstraint:labelActuelHaut];
    NSLayoutConstraint *labelActuelCenter = [NSLayoutConstraint constraintWithItem:labelActuel attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeCenterX multiplier:1.0 constant:0];
    [self addConstraint:labelActuelCenter];
    NSLayoutConstraint *buttonActuelHaut = [NSLayoutConstraint constraintWithItem:buttonActuel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:labelActuel attribute:NSLayoutAttributeBottom multiplier:1.0 constant:5];
    [self addConstraint:buttonActuelHaut];
    NSLayoutConstraint *buttonActuelCenter = [NSLayoutConstraint constraintWithItem:buttonActuel attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeCenterX multiplier:1.0 constant:0];
    [self addConstraint:buttonActuelCenter];
    NSLayoutConstraint *buttonActuelGauche = [NSLayoutConstraint constraintWithItem:buttonActuel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeLeft multiplier:1.0 constant:15];
    [self addConstraint:buttonActuelGauche];
    NSLayoutConstraint *buttonActuelDroite = [NSLayoutConstraint constraintWithItem:buttonActuel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeRight multiplier:1.0 constant:-15];
    [self addConstraint:buttonActuelDroite];
    NSLayoutConstraint *labelRougeHaut = [NSLayoutConstraint constraintWithItem:labelRouge attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:buttonActuel attribute:NSLayoutAttributeBottom multiplier:1.0 constant:5];
    [self addConstraint:labelRougeHaut];
    NSLayoutConstraint *labelRougeGauche = [NSLayoutConstraint constraintWithItem:labelRouge attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeLeft multiplier:1.0 constant:15];
    [self addConstraint:labelRougeGauche];
    NSLayoutConstraint *sliderRougeHaut = [NSLayoutConstraint constraintWithItem:sliderRouge attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:buttonActuel attribute:NSLayoutAttributeBottom multiplier:1.0 constant:10];
    [self addConstraint:sliderRougeHaut];
    NSLayoutConstraint *sliderRougeCenter = [NSLayoutConstraint constraintWithItem:sliderRouge attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeCenterX multiplier:1.0 constant:0];
    [self addConstraint:sliderRougeCenter];
    NSLayoutConstraint *sliderRougeGauche = [NSLayoutConstraint constraintWithItem:sliderRouge attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeLeft multiplier:1.0 constant:15];
    [self addConstraint:sliderRougeGauche];
    NSLayoutConstraint *sliderRougeDroite = [NSLayoutConstraint constraintWithItem:sliderRouge attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeRight multiplier:1.0 constant:-15];
    [self addConstraint:sliderRougeDroite];
    NSLayoutConstraint *labelVertHaut = [NSLayoutConstraint constraintWithItem:labelVert attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:sliderRouge attribute:NSLayoutAttributeBottom multiplier:1.0 constant:5];
    [self addConstraint:labelVertHaut];
    NSLayoutConstraint *labelVertGauche = [NSLayoutConstraint constraintWithItem:labelVert attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeLeft multiplier:1.0 constant:15];
    [self addConstraint:labelVertGauche];
    NSLayoutConstraint *sliderVertHaut = [NSLayoutConstraint constraintWithItem:sliderVert attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:labelVert attribute:NSLayoutAttributeBottom multiplier:1.0 constant:5];
    [self addConstraint:sliderVertHaut];
    NSLayoutConstraint *sliderVertCenter = [NSLayoutConstraint constraintWithItem:sliderVert attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeCenterX multiplier:1.0 constant:0];
    [self addConstraint:sliderVertCenter];
    NSLayoutConstraint *sliderVertGauche = [NSLayoutConstraint constraintWithItem:sliderVert attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeLeft multiplier:1.0 constant:15];
    [self addConstraint:sliderVertGauche];
    NSLayoutConstraint *sliderVertDroite = [NSLayoutConstraint constraintWithItem:sliderVert attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeRight multiplier:1.0 constant:-15];
    [self addConstraint:sliderVertDroite];
    NSLayoutConstraint *labelBleuHaut = [NSLayoutConstraint constraintWithItem:labelBleu attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:sliderVert attribute:NSLayoutAttributeBottom multiplier:1.0 constant:5];
    [self addConstraint:labelBleuHaut];
    NSLayoutConstraint *labelBleuGauche = [NSLayoutConstraint constraintWithItem:labelBleu attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeLeft multiplier:1.0 constant:15];
    [self addConstraint:labelBleuGauche];
    NSLayoutConstraint *sliderBleuHaut = [NSLayoutConstraint constraintWithItem:sliderBleu attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:labelBleu attribute:NSLayoutAttributeBottom multiplier:1.0 constant:5];
    [self addConstraint:sliderBleuHaut];
    NSLayoutConstraint *sliderBleuCenter = [NSLayoutConstraint constraintWithItem:sliderBleu attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeCenterX multiplier:1.0 constant:0];
    [self addConstraint:sliderBleuCenter];
    NSLayoutConstraint *sliderBleuGauche = [NSLayoutConstraint constraintWithItem:sliderBleu attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeLeft multiplier:1.0 constant:15];
    [self addConstraint:sliderBleuGauche];
    NSLayoutConstraint *sliderBleuDroite = [NSLayoutConstraint constraintWithItem:sliderBleu attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeRight multiplier:1.0 constant:-15];
    [self addConstraint:sliderBleuDroite];
    NSLayoutConstraint *buttonMemoriserHaut = [NSLayoutConstraint constraintWithItem:buttonMemoriser attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:sliderBleu attribute:NSLayoutAttributeBottom multiplier:1.0 constant:5];
    [self addConstraint:buttonMemoriserHaut];
    NSLayoutConstraint *buttonMemoriserCenter = [NSLayoutConstraint constraintWithItem:buttonMemoriser attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeCenterX multiplier:1.0 constant:0];
    [self addConstraint:buttonMemoriserCenter];
   NSLayoutConstraint *buttonRazHaut = [NSLayoutConstraint constraintWithItem:buttonRaz attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:buttonMemoriser attribute:NSLayoutAttributeBottom multiplier:1.0 constant:5];
    [self addConstraint:buttonRazHaut];
    NSLayoutConstraint *buttonRazCenter = [NSLayoutConstraint constraintWithItem:buttonRaz attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeCenterX multiplier:1.0 constant:0];
    [self addConstraint:buttonRazCenter];
    NSLayoutConstraint *switchWebBas = [NSLayoutConstraint constraintWithItem:switchWeb attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeBottom multiplier:1.0 constant:-15];
    [self addConstraint:switchWebBas];
    NSLayoutConstraint *switchWebGauche= [NSLayoutConstraint constraintWithItem:switchWeb attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeLeft multiplier:1.0 constant:15];
    [self addConstraint:switchWebGauche];
    NSLayoutConstraint *labelWebBas = [NSLayoutConstraint constraintWithItem:labelWeb attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeBottom multiplier:1.0 constant:-20];
    [self addConstraint:labelWebBas];
    NSLayoutConstraint *labelWebGauche= [NSLayoutConstraint constraintWithItem:labelWeb attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:switchWeb attribute:NSLayoutAttributeRight multiplier:1.0 constant:15];
    [self addConstraint: labelWebGauche];

}


+ (UISwitch *)getSwitchWeb{
    return switchWeb;
}


+ (UIButton *)getButtonActuel{
    return buttonActuel;
}

+ (UIButton *)getButtonPrecedent{
    return buttonPrecedent;
}

+ (UIButton *)getButtonPenultieme{
    return buttonPenultieme;
}

+ (UIButton *)getButtonRaz{
    return buttonRaz;
}


+ (UIButton *)getButtonMemoriser{
    return buttonMemoriser;
}



- (void)dealloc {
    [buttonActuel release];
    [buttonPrecedent release];
    [buttonPenultieme release];
    [labelRouge release];
    [labelVert release];
    [labelBleu release];
    [sliderRouge release];
    [sliderVert release];
    [sliderBleu release];
    [switchWeb release];
    [super dealloc];
}

- (void)handleAff{
    labelRouge.text = [NSString stringWithFormat: @"R: %d %%", (int)(sliderRouge.value * 100)];
    labelBleu.text = [NSString stringWithFormat: @"B: %d %%", (int)(sliderBleu.value * 100)];
    labelVert.text = [NSString stringWithFormat: @"V: %d %%", (int)(sliderVert.value * 100)];
    buttonActuel.backgroundColor = [UIColor colorWithRed:sliderRouge.value green:sliderVert.value blue:sliderBleu.value alpha:1.1];
}



- (void)webMode{
 sliderBleu.value = (round((sliderBleu.value*100)/10)*10)/100;
 sliderVert.value = (round((sliderVert.value*100)/10)*10)/100;
 sliderRouge.value = (round((sliderRouge.value*100)/10)*10)/100;
 [self handleAff];
 }
 
 
 //update la valeur des sliders
 - (void)changeSliderValue:(UISlider *)sender {
 if(switchWeb.isOn)
 [self webMode];
 [self handleAff];
 }
 
 //Enregistre la couleur
 - (void)memorise:(id)sender {
 buttonPenultieme.backgroundColor = buttonPrecedent.backgroundColor;
 buttonPrecedent.backgroundColor = buttonActuel.backgroundColor;
 }
 
 //remet à zero actuel
 - (void)raz:(id)sender {
 sliderRouge.value = 0.5;
 sliderVert.value = 0.5;
 sliderBleu.value = 0.5;
 [self handleAff];
 }
 
 //reset Actuel à la valeur de penul ou précédent
 - (void)recupOld:(UIButton *)sender {
 const CGFloat* components = CGColorGetComponents(sender.backgroundColor.CGColor);
 sliderRouge.value = components[0];
 sliderVert.value = components[1];
 sliderBleu.value = components[2];
 if(switchWeb.isOn)
 [self webMode];
 [self handleAff];
 }
 
 
 
 - (IBAction)setWeb:(id)sender {
 if(switchWeb.isOn)
 [self webMode];
 [self handleAff];
 }


@end
