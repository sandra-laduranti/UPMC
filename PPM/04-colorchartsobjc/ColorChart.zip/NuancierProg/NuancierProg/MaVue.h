//
//  MaVue.h
//  NuancierProg
//
//  Created by m2sar on 18/10/2018.
//  Copyright © 2018 UPMC. All rights reserved.
//

//#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


@interface MaVue : UIView


- (void)handleAff;
- (void)webMode;
- (void)changeSliderValue:(UISlider *)sender;
- (void)memorise:(id)sender;
- (void)raz:(id)sender;
- (void)recupOld:(UIButton *)sender;

+ (UISwitch *)getSwitchWeb;
+ (UIButton *)getButtonActuel;
+ (UIButton *)getButtonPrecedent;
+ (UIButton *)getButtonPenultieme;
+ (UIButton *)getButtonRaz;
+ (UIButton *)getButtonMemoriser;



@end
