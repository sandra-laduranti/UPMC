//
//  ViewController.m
//  NuancierProg
//
//  Created by m2sar on 18/10/2018.
//  Copyright © 2018 UPMC. All rights reserved.
//

#import "ViewController.h"
#import "MaVue.h"

@interface ViewController ()

@end

@implementation ViewController

-(void)loadView
{
    UIScreen *ecran = [UIScreen mainScreen];
    CGRect rect = [ecran bounds];
    MaVue *v = [[MaVue alloc] initWithFrame:rect];
    [self setView:v];
    [v release];
}


- (void)viewDidLoad{
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
  
    /*en théorie il aurait fallut get la view ici et appeler les différentes fonctions avec mais je n'ai pas réussi
     le programme n'est donc pas entierement fonctionnel*/
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}







@end
