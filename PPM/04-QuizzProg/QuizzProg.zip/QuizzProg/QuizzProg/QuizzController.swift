//
//  QuizzController.swift
//  QuizzProg
//
//  Created by m2sar on 22/10/2018.
//  Copyright © 2018 UPMC. All rights reserved.
//

import UIKit

class QuizzController: UIViewController{
    
    
    var currentQuestion = 0
    
    var questionList = Quizz(q:"Quelle est la couleur du cheval blanc d'henri IV?",r:"Blanc",d:false)
    
    override func loadView(){
        print("je te crotte")
        view = QuizzView()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("Controller: viewDidLoad()")
        //set questions
        questionList.addQuestion(q:"La réponse à la grande question sur la vie, l'univers et le reste?",r:"42",d:false)
        questionList.addQuestion(q:"Sur quoi est posé le disque du monde ?",r:"Sur quatre éléphants eux-même posés sur une tortue",d:true)
        questionList.addQuestion(q:"1 + 1 ?",r:"2",d:false)
        questionList.addQuestion(q:"La boule de cristal léguée à Goku par son grand-père a combien d'étoiles?",r:"4",d:true)
        questionList.addQuestion(q:"Qui est l'auteur du Seigneur des anneaux?",r:"J.R.R. Tolkien",d:false)
        
        if var myview = self.view as? QuizzView {
            myview.answerB.addTarget(self, action: #selector(askReponse), for: .touchUpInside)
            myview.nextB.addTarget(self, action: #selector(changeQuestion), for: .touchUpInside)
            myview.prevB.addTarget(self, action: #selector(changeQuestion), for: .touchUpInside)
            myview.CNModeS.addTarget(self, action: #selector(changeDifficulty), for: .touchUpInside)
        }
        
        handleAff(affQuestion: "Quelle est la couleur du cheval blanc d'henri IV?", affReponse: "")
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func handleAff(affQuestion: String, affReponse: String){
        let color:UIColor = questionList.currentDifficulty() ? UIColor.red : UIColor.blue
        let rep:String
        
        if (affReponse == "" && questionList.reponseIsOn()){
            rep = questionList.getCurrentResponse()
        }
        else{
            rep = affReponse
        }
        let repVues = "Answer seen: \(questionList.nbRep)"
        
        if var myview = self.view as? QuizzView {
            myview.handleAff(textColor:color, questionText:affQuestion, reponseText:rep, reponsesVuesText:repVues)
        }
    }
    
    @IBAction func askReponse(_ sender: UIButton) {
        handleAff(affQuestion: questionList.getCurrentQuestion(), affReponse: questionList.getCurrentResponse())
    }
    
    @IBAction func changeQuestion(_ sender: UIButton) {
        if (sender.tag == 0){
            //prev
            handleAff(affQuestion: questionList.prevQuestion(), affReponse: "")
        }
        if (sender.tag == 1){
            //next
            handleAff(affQuestion: questionList.nextQuestion(), affReponse: "")
        }
    }
    
    @IBAction func changeDifficulty(_ sender: UISwitch) {
        questionList.difficulty = sender.isOn ? true : false ;
        
        if(!sender.isOn && questionList.currentDifficulty()){
            questionList.nextQuestion();
            handleAff(affQuestion: questionList.nextQuestion(), affReponse: "")
        }
    }
    
    
}
