//
//  QuizzView.swift
//  QuizzProg
//
//  Created by m2sar on 15/10/2018.
//  Copyright © 2018 UPMC. All rights reserved.
//

import UIKit

class QuizzView: UIView {
    
    private let myDevice = UIDevice.current
    private let screen = UIScreen.main
    
    public let prevB = UIButton()
    public let nextB = UIButton()
    public let answerB = UIButton(type: UIButton.ButtonType.system)
    public let CNModeS = UISwitch()
    
    private let questionL = UILabel()
    private let answerL = UILabel()
    private let seenL = UILabel()
    private let CNModeL = UILabel()
    
    private let questionTV = UITextView()
    private let answerTV = UITextView()
    
    private var top = 0

    
    required init?(coder aDecoder: NSCoder){
        super.init(coder: aDecoder)
        fatalError("init(coder:) error")
    }
    
    override init (frame: CGRect) {
        questionL.textAlignment = .center
        questionL.text = "Question"
        answerL.textAlignment = .center
        answerL.text = "Answer"
        answerTV.textColor = UIColor.green
        seenL.textAlignment = .center
        seenL.text = "Answer seen: 0"
        
        questionTV.textAlignment = .center
        answerTV.textAlignment = .center
        CNModeL.text = "CN Mode"
        
        prevB.setImage(UIImage(named: "gauche"), for: .normal)
        prevB.tag = 0
        nextB.setImage(UIImage(named: "droite"), for: .normal)
        nextB.tag = 1
        answerB.setTitle("The Answer", for: .normal)
        super.init(frame: frame)
        
        self.backgroundColor = UIColor.white
        self.addSubview(prevB)
        self.addSubview(nextB)
        self.addSubview(answerB)
        self.addSubview(CNModeS)
        self.addSubview(questionL)
        self.addSubview(answerL)
        self.addSubview(seenL)
        self.addSubview(CNModeL)
        self.addSubview(questionTV)
        self.addSubview(answerTV)
    }
    
    override func draw(_ rect: CGRect) {
        
        prevB.frame = CGRect(x: CGFloat(20), y: CGFloat(50), width: 40.0, height: 40.0)
        answerB.frame = CGRect(x: CGFloat(rect.size.width/2 - 50), y: CGFloat(50), width:100, height:21.0)
        nextB.frame = CGRect(x: CGFloat(rect.size.width - 60), y: CGFloat(50), width: 40, height: 40)
        questionL.frame = CGRect(x: CGFloat(rect.size.width/2 - 40), y: CGFloat(80), width: 80, height: 21.0)
        questionTV.frame = CGRect(x: CGFloat(20), y: CGFloat(100), width: rect.size.width - 40, height: 50.0)
        answerL.frame = CGRect(x: CGFloat(rect.size.width/2 - 40), y: CGFloat(170), width: 80, height: 21.0)
        answerTV.frame = CGRect(x: CGFloat(20), y: CGFloat(190), width: rect.size.width - 40, height: 50.0)
        seenL.frame = CGRect(x: CGFloat(20), y: CGFloat(rect.size.height - 40), width: 140.0, height: 21.0)
        CNModeS.frame = CGRect(x: CGFloat(rect.size.width - 80), y: CGFloat(rect.size.height - 50), width: 30, height: 21.0)
        CNModeL.frame = CGRect(x: CGFloat(rect.size.width - 100), y: CGFloat(rect.size.height - 70), width: 80, height: 21.0)
        
    }
    
    func handleAff(textColor:UIColor, questionText:String, reponseText:String, reponsesVuesText:String){
        questionTV.textColor = textColor
        questionTV.text = questionText
        answerTV.text = reponseText
        seenL.text = reponsesVuesText
    }
        
    
}
