//
//  ViewController.swift
//  abacus
//
//  Created by m2sar on 08/10/2018.
//  Copyright © 2018 UPMC. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var stepperDiz: UIStepper!
    @IBOutlet weak var sliderDiz: UISegmentedControl!
    @IBOutlet weak var switchGeek: UISwitch!
    @IBOutlet weak var raz: UIButton!
    @IBOutlet weak var sliderUnit: UISegmentedControl!
    @IBOutlet weak var labelValue: UILabel!
    @IBOutlet weak var slider: UISlider!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        stepperDiz.value = 0
        stepperDiz.maximumValue = 99
        stepperDiz.minimumValue = 0
        slider.value = 0
        slider.maximumValue = 99
        slider.minimumValue = 0
        // Do any additional setup after loading the view, typically from a nib.
    }

    func handleView(res:Int) {
        sliderDiz.selectedSegmentIndex = res/10
        sliderUnit.selectedSegmentIndex = res%10
        slider.setValue(Float(res), animated: true)
        stepperDiz.value = Double(res)
    
        labelValue.textColor = (res==42) ? UIColor.red : UIColor.black
        labelValue.text = (switchGeek.isOn==true) ? String(format:"%2X",res) : String(res)
        
    }

    @IBAction func didChangeSegment(sender: UISegmentedControl) {
        handleView(res: sliderDiz.selectedSegmentIndex*10+sliderUnit.selectedSegmentIndex )
    }
    
    @IBAction func didChangeSlider(sender: UISlider){
        handleView(res: Int(slider.value))
    }
    
    @IBAction func didChangeSwitch(sender: UISwitch){
        handleView(res: Int(slider.value))
    }
    
    @IBAction func didChangeStepper(sender: UIStepper){
        handleView(res: Int(stepperDiz.value))
    }
    
    @IBAction func raz(sender: UIButton){
        handleView(res: 0)
    }
    
}

